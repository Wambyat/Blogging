INSERT INTO blog_info VALUES (2 ,"Wow this title",2,"Wow this blog"); 
INSERT INTO blog_info VALUES (5 ,"How to be happy with yourself",3,"Be happy with yourself. Look int the mirrior and say i love you!!!!!!! WOWOWOWOWOWOWOWOW Depression solved."); 
INSERT INTO blog_info VALUES (6 ,"HUH This is a blog??",4,"Never know how to use this to be honest. But i guess this a page."); 