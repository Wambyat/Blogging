Make sure flask is installed as well as sqlite3. Make sure module os is enabled/ allowed as it is used to safely store images.
Preferable run this on a windows machiene it has not been tested on any linux machine.

Do not change or move any files they are in the required directories.

You only need to run test_flask.py in the same way you run any regular python file. test_flask.py is present inside the Testing folder.

Go to http://127.0.0.1:5000/
If the website is not visible there please see the output of the python file. Flask will mention where the website is.


There are a few images in wierd locations please ignore them.

git files are from my private repository.